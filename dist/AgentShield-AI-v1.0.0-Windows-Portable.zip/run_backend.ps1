# AI Agent Firewall - Backend Server Launcher
Write-Host "Starting AI Agent Firewall Backend on http://127.0.0.1:8000 ..." -ForegroundColor Cyan
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
